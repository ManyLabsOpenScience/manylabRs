## ----echo=FALSE----------------------------------------------------------
require(manylabRs)
library(reshape2)
library(plyr)
library(broom)

## ---- eval=FALSE---------------------------------------------------------
#  library(devtools)
#  install_github("ManyLabsOpenScience/manylabRs")

## ------------------------------------------------------------------------
library(manylabRs)
library(tidyverse)

df <- get.analyses(studies = 1, analysis.type = 1)

## ------------------------------------------------------------------------
head(tbl_df(df$raw.case$Huang.1))

## ------------------------------------------------------------------------
glimpse(tbl_df(df$aggregated$Huang.1))

## ------------------------------------------------------------------------
cat(paste0(df$aggregated$Huang.1$test.ConsoleOutput))

